import 'dart:convert';
import 'dart:ui';
import 'package:flutter/animation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'dart:async';
import 'package:xml/xml.dart' as xml;

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  runApp(HomeScreen());
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _isDarkMode = false;
  BannerAd? _bannerAd;
  bool _isAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadDarkModePreference();
    _createBannerAd();
  }

  void _loadDarkModePreference() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isDarkMode = prefs.getBool('isDarkMode') ?? false;
    });
  }

  void _toggleDarkMode(bool value) async {
    setState(() {
      _isDarkMode = value;
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isDarkMode', value);
  }

  void _createBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-3940256099942544/6300978111',
      size: AdSize.banner,
      request: AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) {
          setState(() {
            _isAdLoaded = true;
          });
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          print('Ad failed to load: $error');
        },
      ),
    );

    _bannerAd?.load();
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: _isDarkMode ? ThemeData.dark() : ThemeData.light(),
      home: Scaffold(
        body: Column(
          children: [
            Expanded(
              child: CombinedScreen(toggleDarkMode: _toggleDarkMode, isDarkMode: _isDarkMode),
            ),
            if (_isAdLoaded)
              Container(
                height: _bannerAd!.size.height.toDouble(),
                width: _bannerAd!.size.width.toDouble(),
                child: AdWidget(ad: _bannerAd!),
              ),
          ],
        ),
      ),
    );
  }
}

class CombinedScreen extends StatefulWidget {
  final Function(bool) toggleDarkMode;
  final bool isDarkMode;

  CombinedScreen({required this.toggleDarkMode, required this.isDarkMode});

  @override
  _CombinedScreenState createState() => _CombinedScreenState();
}

class _CombinedScreenState extends State<CombinedScreen> {
  List<dynamic> allStations = [];
  List<Map<String, dynamic>> favoriteStations = [];
  List<dynamic> filteredStations = [];
  List<Map<String, dynamic>> searchHistory = [];
  Set<String> favorites = Set<String>();
  bool isLoading = false;
  TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadJsonData();
    loadSearchHistory();
    loadFavorites();
    loadFavoriteStations();
  }

  Future<void> loadJsonData() async {
    setState(() {
      isLoading = true;
    });

    try {
      String jsonString = await rootBundle.loadString('assets/seoul_subway.json');
      final jsonResponse = json.decode(jsonString);

      if (jsonResponse['DATA'] != null) {
        setState(() {
          allStations = jsonResponse['DATA'];
          allStations.sort((a, b) => a['station_cd'].compareTo(b['station_cd']));
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
        print('JSON 데이터에 "DATA" 키가 없습니다.');
      }
    } catch (error) {
      setState(() {
        isLoading = false;
      });
      print('JSON 데이터를 불러오는 중 오류 발생: $error');
    }
  }

  Future<void> loadSearchHistory() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? history = prefs.getStringList('searchHistory');
    if (history != null) {
      setState(() {
        searchHistory = history.map((item) {
          final parts = item.split('|');
          return {
            'stationName': parts[0],
            'lineNum': parts[1],
          };
        }).toList();
      });
    }
  }

  Future<void> loadFavorites() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    Set<String>? favs = prefs.getStringList('favorites')?.toSet();
    if (favs != null) {
      setState(() {
        favorites = favs;
      });
    }
  }

  Future<void> loadFavoriteStations() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? favStations = prefs.getStringList('favoriteStations');
    if (favStations != null) {
      setState(() {
        favoriteStations = favStations.map((item) {
          final parts = item.split('|');
          return {
            'stationName': parts[0],
            'lineNum': parts[1],
          };
        }).toList();
      });
    }
  }

  void saveSearchHistory() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    final history = searchHistory.map((item) => '${item['stationName']}|${item['lineNum']}').toList();
    await prefs.setStringList('searchHistory', history);
  }

  void saveFavorites() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('favorites', favorites.toList());
  }

  void saveFavoriteStations() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    final favStations = favoriteStations.map((item) => '${item['stationName']}|${item['lineNum']}').toList();
    await prefs.setStringList('favoriteStations', favStations);
  }

  void addSearchHistory(String stationName, String lineNum) {
    final entry = {
      'stationName': stationName,
      'lineNum': lineNum,
    };

    setState(() {
      searchHistory.removeWhere((item) => item['stationName'] == stationName && item['lineNum'] == lineNum);
      searchHistory.insert(0, entry);
      if (searchHistory.length > 10) {
        searchHistory.removeLast();
      }
      saveSearchHistory();
    });
  }

  void removeFromSearchHistory(int index) {
    setState(() {
      searchHistory.removeAt(index);
      saveSearchHistory();
    });
  }

  void toggleFavorite(String stationName, String lineNum) {
    setState(() {
      String key = '$stationName|$lineNum';
      if (favorites.contains(key)) {
        favorites.remove(key);
      } else {
        favorites.add(key);
      }
      saveFavorites();
    });
  }

  void searchStations(String query) {
    final lowerCaseQuery = query.toLowerCase();
    setState(() {
      filteredStations = allStations.where((station) {
        final stationName = station['station_nm'].toLowerCase();
        final lineNum = station['line_num'].toLowerCase();
        return stationName.contains(lowerCaseQuery) || lineNum.contains(lowerCaseQuery);
      }).toList();
    });
  }

  void _showSearchBottomSheet({bool forFavorites = false, int? favoriteIndex}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setModalState) {
            return Container(
              height: MediaQuery.of(context).size.height * 0.97,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _searchController,
                            onChanged: (query) {
                              setModalState(() {
                                searchStations(query);
                              });
                            },
                            autofocus: true,
                            decoration: InputDecoration(
                              labelText: '역 검색',
                              suffixIcon: Icon(Icons.search),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12.0), // 라운드 처리
                                borderSide: BorderSide(
                                  color: Colors.grey, // 보더 색상 설정
                                  width: 1.0, // 보더 두께
                                ),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12.0), // 라운드 처리
                                borderSide: BorderSide(
                                  color: Colors.green, // 비활성 상태 보더 색상
                                  width: 1.0,
                                ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12.0), // 라운드 처리
                                borderSide: BorderSide(
                                  color: Colors.green,
                                  width: 1.0,
                                ),
                              ),
                            ),
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.close),
                          onPressed: () {
                            setModalState(() {
                              _searchController.clear();
                              Navigator.pop(context);
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView.builder(
                      itemCount: filteredStations.length,
                      itemBuilder: (context, index) {
                        final station = filteredStations[index];
                        final stationName = station['station_nm'];
                        final lineNum = station['line_num'];

                        return Card(
                          child: ListTile(
                            title: Text('$stationName - $lineNum'),
                            onTap: () {
                              if (forFavorites) {
                                addToFavorites(stationName, lineNum, favoriteIndex);
                                Navigator.pop(context);
                              } else {
                                addSearchHistory(stationName, lineNum);
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => StationInfoScreen(
                                      stationName: stationName,
                                      lineNum: lineNum,
                                      stations: allStations.where((s) => s['line_num'] == lineNum).toList(),
                                    ),
                                  ),
                                );
                              }
                            },
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }


  void addToFavorites(String stationName, String lineNum, int? index) {
    setState(() {
      if (favoriteStations.length < 4) {
        final newFavorite = {
          'stationName': stationName,
          'lineNum': lineNum,
        };
        if (index != null && index < favoriteStations.length) {
          favoriteStations[index] = newFavorite;
        } else {
          favoriteStations.add(newFavorite);
        }
        saveFavoriteStations();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('즐겨찾기는 최대 4개까지만 가능합니다.')),
        );
      }
    });
  }

  void removeFromFavorites(int index) {
    setState(() {
      favoriteStations.removeAt(index);
      saveFavoriteStations();
    });
  }

  Color _getLineColor(String lineNum) {
    final Map<String, Color> lineColors = {
      '01호선': Colors.blue,
      '02호선': Color(0xFF1CA61C),
      '03호선': Colors.orange,
      '04호선': Colors.pink,
      '05호선': Colors.purple,
      '06호선': Colors.amber,
      '07호선': Color(0xFF214221),
      '08호선': Colors.pinkAccent,
      '09호선': Colors.yellowAccent,
      '중앙선': Colors.orange,
      '경의중앙선': Colors.blue,
      '경춘선': Colors.cyan,
      '수인분당선': Color(0xFF9E9D24),
      '신분당선': Colors.red,
      '우이신설선': Colors.lightGreen,
      '서해선': Colors.blueGrey,
      '경의선': Colors.blueAccent,
      'GTX-A': Color(0xFFAA00FF),
      '공항철도':Color(0xFF28CBDD),
    };
    return lineColors[lineNum] ?? Colors.grey;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
        title: Row(
        children: [
        Container(
        margin: const EdgeInsets.only(right: 8, top: 5),
    child: Icon(
    Icons.directions_subway_filled,
    color: Colors.blue,
    size: 30,
    ),
    ),
    Text(
    '열차위치',
    style: TextStyle(fontSize: 19),
    ),
    ],
    ),
    centerTitle: true,
    ),
    endDrawer: Drawer(
    child: ListView(
    padding: EdgeInsets.zero,
    children: <Widget>[
    SizedBox(
    height: 100.0,
    child: DrawerHeader(
    decoration: BoxDecoration(
    color: Colors.blue,
    ),
    child: Center(
    child: Text(
    '메뉴',
    style: TextStyle(
    color: Colors.white,
    fontSize: 24,
    ),
    ),
    ),
    ),
    ),
    ListTile(
    leading: Icon(Icons.settings),
    title: Text('설정'),
    onTap: () {
    Navigator.push(
    context,
    MaterialPageRoute(
    builder: (context) => SettingsScreen(
    toggleDarkMode: widget.toggleDarkMode,
    isDarkMode: widget.isDarkMode,
    ),
    ),
    );
    },
    ),
    ],
    ),
    ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Column(
        children: [
    GestureDetector(
    onTap: _showSearchBottomSheet,
    child: Container(
    padding: EdgeInsets.all(8.0),
      child: TextField(
        controller: _searchController,
        enabled: false,
        decoration: InputDecoration(
          labelText: '역 검색',
          suffixIcon: Icon(Icons.search, color: Colors.blueGrey),
          border: OutlineInputBorder(
            borderSide: BorderSide(
              color: Colors.red,
              width: 2.0,
            ),
          ),
          disabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(
              color: Colors.green,
              width: 1.0,
            ),
          ),
        ),
      ),
    ),
    ),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 15.0, top: 10.0),
              child: Text(
                '즐겨찾기',
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ),
            Container(
              height: 100,
              margin: EdgeInsets.all(8.0),
              decoration: BoxDecoration(
                color: Colors.blueGrey,
                borderRadius: BorderRadius.circular(10),
              ),
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4,
                  childAspectRatio: 1,
                  crossAxisSpacing: 15,
                  mainAxisSpacing: 15,
                ),
                padding: EdgeInsets.all(8),
                itemCount: favoriteStations.length + 1,
                itemBuilder: (context, index) {
                  if (index < favoriteStations.length) {
                    final station = favoriteStations[index];
                    final lineColor = _getLineColor(station['lineNum']);
                    return GestureDetector(
                      onTap: () {
                        // 즐겨찾기 선택 시 최근 기록에 추가하고 역 정보 화면으로 이동
                        addSearchHistory(station['stationName'], station['lineNum']);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => StationInfoScreen(
                              stationName: station['stationName'],
                              lineNum: station['lineNum'],
                              stations: allStations.where((s) => s['line_num'] == station['lineNum']).toList(),
                            ),
                          ),
                        );
                      },
                      onLongPress: () => removeFromFavorites(index),
                      child: Container(
                        decoration: BoxDecoration(
                          color: lineColor,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              station['stationName'],
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: 4),
                            Text(
                              station['lineNum'],
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.white, fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                    );
                  } else {
                    return GestureDetector(
                      onTap: () {
                        _showSearchBottomSheet(forFavorites: true, favoriteIndex: index);
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.grey,
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        child: Icon(
                          Icons.add_box_rounded,
                          color: Colors.white,
                          size: 30,
                        ),
                      ),
                    );
                  }
                },
              ),
            ),
            Flexible(
              flex: 3,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 15.0, top: 10.0),
                    child: Text(
                      '최근기록',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  ),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.all(8.0),
                      decoration: BoxDecoration(
                        color: Colors.blueGrey[300],
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: ListView.builder(
                        itemCount: searchHistory.length,
                        itemBuilder: (context, index) {
                          final item = searchHistory[index];
                          final Color lineColor = _getLineColor(item['lineNum']);
                          return Container(
                            margin: EdgeInsets.symmetric(vertical: 4.0),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8.0),
                              border: Border.all(
                                color: Colors.white,
                                width: 3.0,
                              ),
                            ),
                            child: ListTile(
                              contentPadding: EdgeInsets.all(8.0),
                              title: Text(
                                '${item['stationName']}',
                                style: TextStyle(
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              trailing: Container(
                                width: 50,
                                height: 50,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: lineColor,
                                ),
                                child: Center(
                                  child: Text(
                                    item['lineNum'],
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                              onTap: () {
                                final stationName = item['stationName'];
                                final lineNum = item['lineNum'];
                                addSearchHistory(stationName, lineNum);
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => StationInfoScreen(
                                      stationName: stationName,
                                      lineNum: lineNum,
                                      stations: allStations
                                          .where((s) => s['line_num'] == lineNum)
                                          .toList(),
                                    ),
                                  ),
                                );
                              },
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      )
    ],
    ),
    );
  }
}

class StationInfoScreen extends StatefulWidget {
  final String stationName;
  final String lineNum;
  final List<dynamic> stations;

  StationInfoScreen({
    required this.stationName,
    required this.lineNum,
    required this.stations,
  });

  @override
  _StationInfoScreenState createState() => _StationInfoScreenState();
}

class _StationInfoScreenState extends State<StationInfoScreen> {
  late PageController _pageController;
  late int selectedIndex;
  List<Map<String, dynamic>> trainInfoList = [];
  bool isLoading = true;
  Timer? _timer;
  String? selectedTrainNo;

  @override
  void initState() {
    super.initState();
    selectedIndex = widget.stations.indexWhere((station) => station['station_nm'] == widget.stationName);
    _pageController = PageController(
      initialPage: selectedIndex,
      viewportFraction: 0.3,
    );
    fetchStationInfo();

    _timer = Timer.periodic(Duration(seconds: 30), (timer) {
      fetchStationInfo();
    });
  }

  String _getSubwayId(String lineNum) {
    final Map<String, String> subwayIds = {
      '01호선': '1001',
      '02호선':  '1002',
      '03호선': '1003',
      '04호선': '1004',
      '05호선': '1005',
      '06호선': '1006',
      '07호선': '1007',
      '08호선': '1008',
      '09호선': '1009',
      '중앙선': '1061',
      '경의중앙선': '1063',
      '공항철도': '1065',
      '경춘선': '1067',
      '수인분당선': '1075',
      '신분당선': '1077',
      '우이신설선': '1092',
      'GTX-A': '1032'
    };
    return subwayIds[lineNum] ?? '';
  }

  Future<void> fetchStationInfo() async {
    setState(() {
      isLoading = true;
    });

    String apiKey = '74486d6e56636e643835787a616245';
    String url = 'http://swopenAPI.seoul.go.kr/api/subway/$apiKey/xml/realtimeStationArrival/ALL';
    print('Fetching data from URL: $url'); // 디버깅을 위한 URL 출력

    try {
      final response = await http.get(Uri.parse(url));
      print('Response status code: ${response.statusCode}');

      if (response.statusCode == 200) {
        var decodedBody = utf8.decode(response.bodyBytes);
        var document = xml.XmlDocument.parse(decodedBody);
        var items = document.findAllElements('row');

        print('Number of items found: ${items.length}');

        String targetSubwayId = _getSubwayId(widget.lineNum);
        List<Map<String, dynamic>> allTrainInfo = items.where((item) {
          return _findElementText(item, 'subwayId') == targetSubwayId;
        }).map((item) {
          return {
            'subwayId': _findElementText(item, 'subwayId'),
            'updnLine': _findElementText(item, 'updnLine'),
            'trainLineNm': _findElementText(item, 'trainLineNm'),
            'statnNm': _findElementText(item, 'statnNm'),
            'btrainSttus': _findElementText(item, 'btrainSttus'),
            'barvlDt': _findElementText(item, 'barvlDt'),
            'btrainNo': _findElementText(item, 'btrainNo'),
            'bstatnNm': _findElementText(item, 'bstatnNm'),
            'recptnDt': _findElementText(item, 'recptnDt'),
            'arvlMsg2': _findElementText(item, 'arvlMsg2'),
            'arvlMsg3': _findElementText(item, 'arvlMsg3'),
            'arvlCd': _findElementText(item, 'arvlCd'),
          };
        }).toList();

        setState(() {
          trainInfoList = allTrainInfo;
          isLoading = false;
        });

        print('Train info for ${widget.lineNum}: ${trainInfoList.length} trains');
        if (trainInfoList.isNotEmpty) {
          print('Sample train info: ${trainInfoList[0]}');
        }
      } else {
        throw Exception('Failed to load train info. Status code: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print('Error fetching station info: $e');
    }
  }

  String _findElementText(xml.XmlElement item, String elementName) {
    try {
      return item.findElements(elementName).single.text;
    } catch (e) {
      print('Error finding element $elementName: $e');
      return '';
    }
  }

  void _centerTrainIcon(String trainNo) {
    setState(() {
      selectedTrainNo = trainNo;
    });

    // Find the index of the station where the train is currently located
    int trainStationIndex = widget.stations.indexWhere((station) {
      return trainInfoList.any((train) =>
      train['btrainNo'] == trainNo && train['arvlMsg3'] == station['station_nm']
      );
    });

    if (trainStationIndex != -1) {
      _pageController.animateToPage(
        trainStationIndex,
        duration: Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  Color _getLineColor(String lineNum) {
    final Map<String, Color> lineColors = {
      '01호선': Colors.blue,
      '02호선': Color(0xFF1CA61C),
      '03호선': Colors.orange,
      '04호선': Colors.pink,
      '05호선': Colors.purple,
      '06호선': Colors.amber,
      '07호선': Color(0xFF214221),
      '08호선': Colors.pinkAccent,
      '09호선': Colors.yellowAccent,
      '중앙선': Colors.orange,
      '경의중앙선': Colors.blue,
      '경춘선': Colors.cyan,
      '수인분당선': Color(0xFF9E9D24),
      '신분당선': Colors.red,
      '우이신설선': Colors.lightGreen,
      '서해선': Colors.blueGrey,
      '경의선': Colors.blueAccent,
      'GTX-A': Color(0xFFAA00FF),
      '공항철도':Color(0xFF28CBDD),
    };
    return lineColors[lineNum] ?? Colors.grey;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.stationName} - ${widget.lineNum}'),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Column(
        children: [
          SizedBox(height: 20),
          Container(
            height: 250,
            child: PageView.builder(
              controller: _pageController,
              itemCount: widget.stations.length,
              itemBuilder: (context, index) {
                final station = widget.stations[index];
                final stationName = station['station_nm'];
                final matchingTrains = trainInfoList.where((train) {
                  return train['arvlMsg3'] == stationName;
                }).toList();
                // 중복 제거를 위해 Set 사용
                final uniqueTrains = <String, Map<String, dynamic>>{};
                for (var train in matchingTrains) {
                  uniqueTrains[train['btrainNo']] = train;
                }

                return Column(
                  children: [
                    Expanded(
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          CustomPaint(
                            size: Size(MediaQuery.of(context).size.width, 50),
                            painter: LinePainter(
                              isLeftStation: index > 0,
                              isRightStation: index < widget.stations.length - 1,
                              lineColor: _getLineColor(widget.lineNum),
                            ),
                          ),
                          StationMarker(
                            stationName: stationName,
                            isSelected: stationName == widget.stationName,
                            trainInfoList: trainInfoList,
                            stations: widget.stations,
                            lineColor: _getLineColor(widget.lineNum),
                          ),
                          ...matchingTrains.map((train) {
                            final isExpress = train['btrainSttus'] == '급행';
                            final isUpward = train['updnLine'] == '상행';
                            final isSelected = train['btrainNo'] == selectedTrainNo;
                            return Positioned(
                              top: isUpward ? 30 : 150,
                              child: Column(
                                children: [
                                  Container(
                                    padding: EdgeInsets.all(2),
                                    decoration: BoxDecoration(
                                      color: Colors.black.withOpacity(0.7),
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    child: Text(
                                      '${train['bstatnNm'] ?? ''}\n${train['btrainNo'] ?? ''}',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 2),
                                  TrainIcon(
                                    lineColor: _getLineColor(widget.lineNum),
                                    isExpress: isExpress,
                                    isUpward: isUpward,
                                    trainNo: train['btrainNo'] ?? '',
                                    destination: train['bstatnNm'] ?? '',
                                    stations: widget.stations,
                                    isSelected: isSelected,
                                  ),
                                  SizedBox(height: 2),
                                ],
                              ),
                            );
                          }).toList(),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
          Expanded(
            child: DefaultTabController(
              length: 2,
              child: Column(
                children: [
                  TabBar(
                    tabs: [
                      Tab(text: '상행'),
                      Tab(text: '하행'),
                    ],
                  ),
                  Expanded(
                    child: TabBarView(
                      children: [
                        _buildTrainList(false),
                        _buildTrainList(true),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTrainList(bool isUpward) {
    final filteredTrains = trainInfoList.where((train) =>
    train['statnNm'] == widget.stationName &&
        ((isUpward && train['updnLine'].toString() == '상행') || (!isUpward && train['updnLine'].toString() == '하행'))
    ).toList();

    filteredTrains.sort((a, b) {
      int aTime = int.tryParse(a['barvlDt'] ?? '') ?? 0;
      int bTime = int.tryParse(b['barvlDt'] ?? '') ?? 0;
      return aTime.compareTo(bTime);
    });

    return ListView.builder(
      itemCount: filteredTrains.length,
      itemBuilder: (context, index) {
        final train = filteredTrains[index];
        return GestureDetector(
          onTap: () => _centerTrainIcon(train['btrainNo']),
          child: Card(
            margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${train['bstatnNm']} 방면',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    '도착 예정: ${_formatArrivalTime(train['barvlDt'])}',
                    style: TextStyle(fontSize: 16, color: Colors.blue),
                  ),
                  Text(
                    '현재 위치: ${train['arvlMsg2'] ?? '정보 없음'}',
                    style: TextStyle(fontSize: 14),
                  ),
                  Text(
                    '열차 번호: ${train['btrainNo'] ?? '정보 없음'}',
                    style: TextStyle(fontSize: 14),
                  ),
                  if (train['btrainSttus'] != null && train['btrainSttus'].isNotEmpty)
                    Text(
                      '열차 상태: ${train['btrainSttus']}',
                      style: TextStyle(fontSize: 14),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
  String _formatArrivalTime(String? barvlDt) {
    if (barvlDt == null || barvlDt.isEmpty) return '정보 없음';
    int seconds = int.tryParse(barvlDt) ?? 0;
    if (seconds == 0) return '곧 도착';
    if (seconds < 60) return '$seconds초 후';
    int minutes = seconds ~/ 60;
    return '$minutes분 후';
  }

  @override
  void dispose() {
    _pageController.dispose();
    _timer?.cancel();
    super.dispose();
  }
}

class TrainIcon extends StatelessWidget {
  final Color lineColor;
  final bool isExpress;
  final bool isUpward;
  final String trainNo;
  final String destination;
  final List<dynamic> stations;
  final bool isSelected;

  TrainIcon({
    required this.lineColor,
    required this.isExpress,
    required this.isUpward,
    required this.trainNo,
    required this.destination,
    required this.stations,
    required this.isSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Icon(
          isExpress ? Icons.train : Icons.train,
          color: isSelected ? Colors.yellow : (isExpress ? Colors.red : lineColor),
          size: isSelected ? 30 : 25,
        ),
      ),
    );
  }
}

class LinePainter extends CustomPainter {
  final bool isLeftStation;
  final bool isRightStation;
  final Color lineColor;

  LinePainter({
    required this.isLeftStation,
    required this.isRightStation,
    required this.lineColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = lineColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;


  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class StationMarker extends StatelessWidget {
  final String stationName;
  final bool isSelected;
  final List<Map<String, dynamic>> trainInfoList;
  final List<dynamic> stations;
  final Color lineColor;

  const StationMarker({
    Key? key,
    required this.stationName,
    required this.isSelected,
    required this.trainInfoList,
    required this.stations,
    required this.lineColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              // 선 그리기
              Container(
                width: 500,  // 선의 너비를 늘려 원이 완전히 포함되도록 함
                height: 8,
                color: lineColor,
              ),
              // 역 원 그리기
              Container(
                width: 20,
                height: 30,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isSelected ? Colors.red : Colors.white,
                  border: Border.all(color: lineColor, width: 3),
                ),
              ),
            ],
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 5, vertical: 4),
            decoration: BoxDecoration(
              color: lineColor,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              stationName,
              style: TextStyle(
                color: Colors.white,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SettingsScreen extends StatelessWidget {
  final Function(bool) toggleDarkMode;
  final bool isDarkMode;

  SettingsScreen({required this.toggleDarkMode, required this.isDarkMode});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('설정'),
      ),
      body: ListView(
        children: [
          SwitchListTile(
            title: Text('다크 모드'),
            value: isDarkMode,
            onChanged: (value) {
              toggleDarkMode(value);
            },
            activeColor: Colors.blue,
            inactiveThumbColor: Colors.grey,
            inactiveTrackColor: Colors.grey.shade300,
          ),
          Text(""),
        ],
      ),
    );
  }
}